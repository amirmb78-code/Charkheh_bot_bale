// اسکریپت تست یکپارچه جریان گفتگوی ربات نمکی — بدون نیاز به سرور واقعی بله
// اجرا: npx tsx scripts/test-bale-flow.mts

process.env.DATABASE_URL ??= "postgresql://postgres:postgres@127.0.0.1:5432/app_db";
process.env.BALE_BOT_TOKEN = "TEST_TOKEN";
process.env.ADMIN_CHAT_ID = "999999";

const CUSTOMER_CHAT = "555111222";
const ADMIN_CHAT = process.env.ADMIN_CHAT_ID;

const sentMessages: { chatId: string; text: string; hasKeyboard: boolean }[] = [];

// موک fetch برای شبیه‌سازی پاسخ‌های API بله بدون تماس شبکه واقعی
const originalFetch = globalThis.fetch;
globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
  const url = typeof input === "string" ? input : input.toString();

  if (url.includes("/getFile")) {
    return jsonResponse({ ok: true, result: { file_id: "FAKE", file_path: "photos/fake.jpg" } });
  }
  if (url.includes("/file/bot")) {
    return {
      ok: true,
      status: 200,
      arrayBuffer: async () => new TextEncoder().encode("fake-image-bytes").buffer,
    } as unknown as Response;
  }
  if (url.includes("/sendMessage")) {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    sentMessages.push({
      chatId: String(body.chat_id),
      text: String(body.text ?? ""),
      hasKeyboard: Boolean(body.reply_markup),
    });
    return jsonResponse({ ok: true, result: { message_id: Math.floor(Math.random() * 100000) } });
  }
  if (url.includes("/sendPhoto")) {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    sentMessages.push({
      chatId: String(body.chat_id),
      text: String(body.caption ?? "[photo]"),
      hasKeyboard: Boolean(body.reply_markup),
    });
    return jsonResponse({ ok: true, result: { message_id: Math.floor(Math.random() * 100000) } });
  }
  if (url.includes("/answerCallbackQuery") || url.includes("/editMessageReplyMarkup")) {
    return jsonResponse({ ok: true, result: {} });
  }
  return jsonResponse({ ok: true, result: {} });
}) as typeof fetch;

function jsonResponse(payload: unknown): Response {
  return {
    ok: true,
    status: 200,
    json: async () => payload,
  } as unknown as Response;
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) {
    throw new Error(`❌ FAILED: ${message}`);
  }
  console.log(`✅ ${message}`);
}

async function main() {
  const { processBaleUpdate } = await import("../src/lib/baleConversation");
  const { db } = await import("../src/db");
  const { customers, pickupRequests, conversationStates } = await import("../src/db/schema");
  const { eq } = await import("drizzle-orm");

  // پاک‌سازی داده‌های تست قبلی (در صورت وجود)
  await db.delete(customers).where(eq(customers.chatId, CUSTOMER_CHAT));
  await db.delete(conversationStates).where(eq(conversationStates.chatId, CUSTOMER_CHAT));
  await db.delete(conversationStates).where(eq(conversationStates.chatId, ADMIN_CHAT!));

  let updateId = 1;

  // ۱) مشتری /start می‌زند
  await processBaleUpdate({
    update_id: updateId++,
    message: {
      message_id: 1,
      chat: { id: Number(CUSTOMER_CHAT) },
      from: { id: Number(CUSTOMER_CHAT), first_name: "علی", username: "ali_test" },
      text: "/start",
    },
  });
  const [customer] = await db.select().from(customers).where(eq(customers.chatId, CUSTOMER_CHAT));
  assert(customer, "مشتری پس از /start ساخته شد");

  // ۲) مشتری عکس می‌فرستد
  await processBaleUpdate({
    update_id: updateId++,
    message: {
      message_id: 2,
      chat: { id: Number(CUSTOMER_CHAT) },
      from: { id: Number(CUSTOMER_CHAT) },
      photo: [{ file_id: "FAKE_PHOTO_1", width: 800, height: 600 }],
    },
  });
  let [request] = await db
    .select()
    .from(pickupRequests)
    .where(eq(pickupRequests.customerId, customer.id));
  assert(request?.status === "awaiting_type", "درخواست پس از دریافت عکس در وضعیت awaiting_type است");
  assert(request?.photoFileId === "FAKE_PHOTO_1", "file_id عکس درست ذخیره شد");

  const requestId = request.id;

  // ۳) مشتری نوع کالا را انتخاب می‌کند (دکمه شیشه‌ای)
  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq1",
      from: { id: Number(CUSTOMER_CHAT) },
      message: { message_id: 10, chat: { id: Number(CUSTOMER_CHAT) } },
      data: `wt:${requestId}:plastic`,
    },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "awaiting_review", "پس از انتخاب نوع کالا وضعیت awaiting_review شد");
  assert(request.wasteType === "plastic", "نوع کالا درست ثبت شد");
  assert(
    sentMessages.some((m) => m.chatId === ADMIN_CHAT && m.text.includes(`#${requestId}`)),
    "پیام درخواست جدید برای ادمین ارسال شد",
  );

  // ۴) ادمین دکمه «ثبت قیمت پیشنهادی» را می‌زند
  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq2",
      from: { id: Number(ADMIN_CHAT) },
      message: { message_id: 11, chat: { id: Number(ADMIN_CHAT) } },
      data: `adm_q:${requestId}`,
    },
  });
  let [adminState] = await db.select().from(conversationStates).where(eq(conversationStates.chatId, ADMIN_CHAT!));
  assert(adminState?.state === "awaiting_quote" && adminState.requestId === requestId, "حالت گفتگوی ادمین روی awaiting_quote تنظیم شد");

  // ۵) ادمین مبلغ نامعتبر می‌فرستد (باید رد شود، نه کرش)
  await processBaleUpdate({
    update_id: updateId++,
    message: { message_id: 12, chat: { id: Number(ADMIN_CHAT) }, text: "نامعتبر" },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "awaiting_review", "مبلغ نامعتبر وضعیت را تغییر نداد");

  // ۶) ادمین مبلغ معتبر می‌فرستد
  await processBaleUpdate({
    update_id: updateId++,
    message: { message_id: 13, chat: { id: Number(ADMIN_CHAT) }, text: "85000" },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "quoted" && request.quotedPrice === 85000, "قیمت با موفقیت ثبت و ارسال شد");
  assert(
    sentMessages.some(
      (m) => m.chatId === CUSTOMER_CHAT && m.hasKeyboard && m.text.includes("قیمت پیشنهادی"),
    ),
    "پیام قیمت با دکمه‌های تایید/انصراف برای مشتری ارسال شد (رفع باگ اصلی)",
  );

  // ۷) مشتری قیمت را تایید می‌کند
  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq3",
      from: { id: Number(CUSTOMER_CHAT) },
      message: { message_id: 14, chat: { id: Number(CUSTOMER_CHAT) } },
      data: `confirm:${requestId}`,
    },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "confirmed", "مشتری قیمت را تایید کرد");
  let [custState] = await db.select().from(conversationStates).where(eq(conversationStates.chatId, CUSTOMER_CHAT));
  assert(custState?.state === "awaiting_address", "حالت گفتگوی مشتری روی awaiting_address تنظیم شد (روند آدرس مشخص است)");

  // ۸) مشتری آدرس می‌فرستد
  await processBaleUpdate({
    update_id: updateId++,
    message: { message_id: 15, chat: { id: Number(CUSTOMER_CHAT) }, text: "تهران، خیابان آزادی، کوچه گلها، پلاک ۱۲" },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "awaiting_time", "پس از آدرس، وضعیت awaiting_time شد");
  assert(request.address?.includes("آزادی"), "آدرس درست ذخیره شد");

  // ۹) مشتری زمان را انتخاب می‌کند (روند هماهنگی زمان/مکان مشخص است)
  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq4",
      from: { id: Number(CUSTOMER_CHAT) },
      message: { message_id: 16, chat: { id: Number(CUSTOMER_CHAT) } },
      data: `time:${requestId}:today_evening`,
    },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "scheduled" && request.preferredTime === "امروز عصر", "زمان تحویل هماهنگ شد");
  assert(
    sentMessages.some((m) => m.chatId === ADMIN_CHAT && m.text.includes("جمع‌آوری") && m.hasKeyboard),
    "ادمین برای مراجعه حضوری مطلع شد",
  );

  // ۱۰) ادمین «جمع‌آوری انجام شد» را می‌زند
  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq5",
      from: { id: Number(ADMIN_CHAT) },
      message: { message_id: 17, chat: { id: Number(ADMIN_CHAT) } },
      data: `adm_done:${requestId}`,
    },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "collected", "وضعیت به collected تغییر کرد");

  // ۱۱) ادمین وزن نهایی را می‌فرستد
  await processBaleUpdate({
    update_id: updateId++,
    message: { message_id: 18, chat: { id: Number(ADMIN_CHAT) }, text: "4.5" },
  });
  [adminState] = await db.select().from(conversationStates).where(eq(conversationStates.chatId, ADMIN_CHAT!));
  assert(adminState?.state === "awaiting_final_price", "وزن ثبت شد و منتظر مبلغ نهایی است");

  // ۱۲) ادمین مبلغ نهایی را می‌فرستد
  await processBaleUpdate({
    update_id: updateId++,
    message: { message_id: 19, chat: { id: Number(ADMIN_CHAT) }, text: "92000" },
  });
  [request] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, requestId));
  assert(request.status === "completed", "سفارش تکمیل شد");
  assert(request.finalPrice === 92000, "مبلغ نهایی درست ثبت شد");
  assert(request.rewardAmount === Math.round((92000 * 12) / 100), "پاداش با درصد صحیح محاسبه شد");
  assert(
    sentMessages.some((m) => m.chatId === CUSTOMER_CHAT && m.text.includes("کد دعوت")),
    "پیام نهایی با کد دعوت برای مشتری ارسال شد",
  );

  // --- تست مسیر رد کردن (کم‌ارزش) و لغو توسط مشتری ---
  await processBaleUpdate({
    update_id: updateId++,
    message: {
      message_id: 20,
      chat: { id: Number(CUSTOMER_CHAT) },
      from: { id: Number(CUSTOMER_CHAT) },
      photo: [{ file_id: "FAKE_PHOTO_2" }],
    },
  });
  const rows2 = await db
    .select()
    .from(pickupRequests)
    .where(eq(pickupRequests.customerId, customer.id));
  const request2 = rows2.sort((a, b) => b.id - a.id)[0];

  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq6",
      from: { id: Number(CUSTOMER_CHAT) },
      message: { message_id: 21, chat: { id: Number(CUSTOMER_CHAT) } },
      data: `wt:${request2.id}:paper`,
    },
  });
  await processBaleUpdate({
    update_id: updateId++,
    callback_query: {
      id: "cbq7",
      from: { id: Number(ADMIN_CHAT) },
      message: { message_id: 22, chat: { id: Number(ADMIN_CHAT) } },
      data: `adm_r:${request2.id}`,
    },
  });
  const [rejected] = await db.select().from(pickupRequests).where(eq(pickupRequests.id, request2.id));
  assert(rejected.status === "low_value_queued", "مسیر رد کردن (کم‌ارزش) درست کار می‌کند");

  // پاک‌سازی داده‌های تست
  await db.delete(customers).where(eq(customers.chatId, CUSTOMER_CHAT));
  await db.delete(conversationStates).where(eq(conversationStates.chatId, CUSTOMER_CHAT));
  await db.delete(conversationStates).where(eq(conversationStates.chatId, ADMIN_CHAT!));

  globalThis.fetch = originalFetch;
  console.log("\n🎉 همه تست‌های جریان گفتگوی ربات با موفقیت پاس شدند.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
