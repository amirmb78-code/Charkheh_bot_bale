import { db } from "@/db";
import { pickupRequests, requestEvents, customers } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function createRequest(params: {
  customerId: number;
  photoFileId: string;
  photoLocalPath: string | null;
}) {
  const [request] = await db
    .insert(pickupRequests)
    .values({
      customerId: params.customerId,
      photoFileId: params.photoFileId,
      photoLocalPath: params.photoLocalPath ?? undefined,
      status: "awaiting_type",
    })
    .returning();
  await logEvent(request.id, "awaiting_type", "عکس دریافت شد");
  return request;
}

export async function getRequestById(id: number) {
  const rows = await db.select().from(pickupRequests).where(eq(pickupRequests.id, id));
  return rows[0] ?? null;
}

export async function getRequestWithCustomer(id: number) {
  const rows = await db
    .select({ request: pickupRequests, customer: customers })
    .from(pickupRequests)
    .innerJoin(customers, eq(pickupRequests.customerId, customers.id))
    .where(eq(pickupRequests.id, id));
  return rows[0] ?? null;
}

export async function updateRequest(
  id: number,
  values: Partial<typeof pickupRequests.$inferInsert>,
) {
  const [updated] = await db
    .update(pickupRequests)
    .set({ ...values, updatedAt: new Date() })
    .where(eq(pickupRequests.id, id))
    .returning();
  return updated;
}

export async function logEvent(requestId: number, status: string, note?: string) {
  await db.insert(requestEvents).values({ requestId, status, note });
}
