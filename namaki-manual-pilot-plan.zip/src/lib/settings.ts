import { db } from "@/db";
import { botSettings, materialRates } from "@/db/schema";
import { eq } from "drizzle-orm";

export const DEFAULT_MIN_ACCEPT_VALUE = 50_000; // تومان
export const DEFAULT_REWARD_PERCENT = 12; // درصد

const DEFAULT_MATERIAL_RATES = [
  { material: "paper", label: "کاغذ", pricePerKg: 3500 },
  { material: "plastic", label: "پلاستیک", pricePerKg: 4000 },
  { material: "metal", label: "فلز", pricePerKg: 9000 },
  { material: "glass", label: "شیشه", pricePerKg: 1500 },
];

export async function ensureSeedData(): Promise<void> {
  const existingRates = await db.select().from(materialRates).limit(1);
  if (existingRates.length === 0) {
    await db.insert(materialRates).values(DEFAULT_MATERIAL_RATES).onConflictDoNothing();
  }

  const minAccept = await db
    .select()
    .from(botSettings)
    .where(eq(botSettings.key, "min_accept_value"));
  if (minAccept.length === 0) {
    await db
      .insert(botSettings)
      .values({ key: "min_accept_value", value: String(DEFAULT_MIN_ACCEPT_VALUE) })
      .onConflictDoNothing();
  }

  const rewardPercent = await db
    .select()
    .from(botSettings)
    .where(eq(botSettings.key, "reward_percent"));
  if (rewardPercent.length === 0) {
    await db
      .insert(botSettings)
      .values({ key: "reward_percent", value: String(DEFAULT_REWARD_PERCENT) })
      .onConflictDoNothing();
  }
}

export async function getSetting(key: string, fallback: string): Promise<string> {
  const rows = await db.select().from(botSettings).where(eq(botSettings.key, key));
  return rows[0]?.value ?? fallback;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db
    .insert(botSettings)
    .values({ key, value, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: botSettings.key,
      set: { value, updatedAt: new Date() },
    });
}

export async function getMinAcceptValue(): Promise<number> {
  const value = await getSetting("min_accept_value", String(DEFAULT_MIN_ACCEPT_VALUE));
  return Number(value) || DEFAULT_MIN_ACCEPT_VALUE;
}

export async function getRewardPercent(): Promise<number> {
  const value = await getSetting("reward_percent", String(DEFAULT_REWARD_PERCENT));
  return Number(value) || DEFAULT_REWARD_PERCENT;
}

export async function getMaterialRates() {
  await ensureSeedData();
  return db.select().from(materialRates).orderBy(materialRates.material);
}
