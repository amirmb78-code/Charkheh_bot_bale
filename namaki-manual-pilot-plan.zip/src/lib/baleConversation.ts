import { db } from "@/db";
import { customers, pickupRequests } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  sendMessage,
  sendPhotoByFileId,
  answerCallbackQuery,
  editMessageReplyMarkup,
  type InlineKeyboard,
} from "@/lib/bale";
import type { BaleUpdate, BaleMessage, BaleCallbackQuery } from "@/lib/baleTypes";
import { getOrCreateCustomer, getCustomerById, generateInviteCode } from "@/lib/customers";
import { createRequest, getRequestById, getRequestWithCustomer, updateRequest, logEvent } from "@/lib/requests";
import { getConversationState, setConversationState, clearConversationState } from "@/lib/convState";
import { savePhotoLocally } from "@/lib/photoStorage";
import { ensureSeedData, getRewardPercent } from "@/lib/settings";
import { toToman, statusLabel, wasteTypeLabel, WASTE_TYPES, TIME_SLOTS, timeSlotLabel } from "@/lib/persian";

function adminChatId(): string | null {
  return process.env.ADMIN_CHAT_ID ?? null;
}

function isAdmin(chatId: string): boolean {
  const admin = adminChatId();
  return Boolean(admin) && String(admin) === String(chatId);
}

function appBaseUrl(): string | null {
  const url = process.env.APP_BASE_URL;
  return url ? url.replace(/\/$/, "") : null;
}

function parseIntLoose(text: string): number | null {
  const digits = text.replace(/[^\d]/g, "");
  if (!digits) return null;
  const n = Number(digits);
  return Number.isNaN(n) ? null : n;
}

function parseFloatLoose(text: string): number | null {
  const cleaned = text.replace(/[^\d.]/g, "");
  if (!cleaned) return null;
  const n = Number(cleaned);
  return Number.isNaN(n) ? null : n;
}

// ---------------------------------------------------------------------------
// نقطه ورود اصلی
// ---------------------------------------------------------------------------
export async function processBaleUpdate(update: BaleUpdate): Promise<void> {
  await ensureSeedData();

  try {
    if (update.callback_query) {
      await handleCallbackQuery(update.callback_query);
      return;
    }
    if (update.message) {
      await handleMessage(update.message);
      return;
    }
  } catch (err) {
    console.error("خطای پردازش آپدیت بله:", err);
  }
}

// ---------------------------------------------------------------------------
// پیام‌های متنی / عکس
// ---------------------------------------------------------------------------
function extractImageFileId(message: BaleMessage): string | null {
  if (message.photo && message.photo.length > 0) {
    return message.photo[message.photo.length - 1].file_id;
  }
  if (message.document?.mime_type?.startsWith("image/")) {
    return message.document.file_id;
  }
  return null;
}

async function handleMessage(message: BaleMessage): Promise<void> {
  const chatId = String(message.chat.id);
  const text = (message.text ?? "").trim();

  if (isAdmin(chatId)) {
    await handleAdminMessage(chatId, text);
    return;
  }

  const customer = await getOrCreateCustomer(chatId, message.from);

  const imageFileId = extractImageFileId(message);
  if (imageFileId) {
    await handleCustomerPhoto(customer.id, chatId, imageFileId);
    return;
  }

  if (text === "/start") {
    await sendWelcome(chatId);
    return;
  }

  if (text === "/status" || text === "/سفارش") {
    await sendCustomerStatus(chatId, customer.id);
    return;
  }

  const state = await getConversationState(chatId);
  if (state && text) {
    await handleCustomerStateInput(chatId, state, text);
    return;
  }

  await sendMessage(
    chatId,
    "برای دریافت قیمت فقط کافیه عکس واضحی از کالا یا پسماندت رو همینجا بفرستی 📷\n\nبرای دیدن وضعیت سفارش‌هات دستور /status رو بفرست.",
  );
}

async function sendWelcome(chatId: string): Promise<void> {
  const welcome = [
    "سلام 👋 به «نمکی» خوش اومدی!",
    "",
    "ما پسماند خشک (کاغذ، پلاستیک، فلز، شیشه) و کالای دسته‌دوم سالم رو از شما می‌خریم و در ازاش اعتبار یا وجه نقد پرداخت می‌کنیم.",
    "",
    "📷 برای شروع فقط کافیه یک عکس واضح از کالا/پسماندت رو همینجا بفرستی.",
    "",
    "🔒 نکته مهم درباره حریم خصوصی:",
    "• لطفاً فقط از خودِ کالا عکس بگیر، نه از فضای داخلی خانه یا افراد.",
    "• عکس شما فقط برای برآورد اولیه قیمت بررسی می‌شود.",
    "• آدرس دقیق شما فقط تا پایان جمع‌آوری نگهداری و سپس حذف می‌شود.",
    "",
    "هر وقت آماده بودی عکس رو بفرست 🙌",
    "برای دیدن وضعیت سفارش‌هات: /status",
  ].join("\n");
  await sendMessage(chatId, welcome);
}

async function sendCustomerStatus(chatId: string, customerId: number): Promise<void> {
  const rows = await db
    .select()
    .from(pickupRequests)
    .where(eq(pickupRequests.customerId, customerId))
    .orderBy(desc(pickupRequests.createdAt))
    .limit(5);

  if (rows.length === 0) {
    await sendMessage(chatId, "هنوز درخواستی ثبت نکردی. یک عکس از کالات بفرست تا شروع کنیم 📷");
    return;
  }

  const lines = rows.map((r) => {
    const parts = [`#${r.id} — ${statusLabel(r.status)}`];
    if (r.quotedPrice) parts.push(`قیمت پیشنهادی: ${toToman(r.quotedPrice)} تومان`);
    if (r.finalPrice) parts.push(`مبلغ نهایی: ${toToman(r.finalPrice)} تومان`);
    return parts.join(" | ");
  });

  await sendMessage(chatId, ["📋 آخرین سفارش‌های تو:", "", ...lines].join("\n"));
}

async function handleCustomerPhoto(customerId: number, chatId: string, fileId: string): Promise<void> {
  const localPath = await savePhotoLocally(fileId);
  const request = await createRequest({ customerId, photoFileId: fileId, photoLocalPath: localPath });

  const keyboard: InlineKeyboard = chunk(
    WASTE_TYPES.map((w) => ({ text: w.label, callback_data: `wt:${request.id}:${w.key}` })),
    2,
  );

  await sendMessage(
    chatId,
    "عکس دریافت شد ✅\nلطفاً نوع کالا/پسماند رو مشخص کن تا سریع‌تر بررسی بشه:",
    keyboard,
  );
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

async function handleCustomerStateInput(
  chatId: string,
  state: { state: string; requestId: number | null },
  text: string,
): Promise<void> {
  if (!state.requestId) {
    await clearConversationState(chatId);
    return;
  }
  const request = await getRequestById(state.requestId);
  if (!request) {
    await clearConversationState(chatId);
    return;
  }

  if (state.state === "awaiting_address") {
    if (text.length < 6) {
      await sendMessage(chatId, "لطفاً آدرس رو کامل‌تر بنویس (خیابان، کوچه، پلاک، واحد) 🙏");
      return;
    }
    await updateRequest(request.id, { address: text, status: "awaiting_time" });
    await logEvent(request.id, "awaiting_time", "آدرس دریافت شد");
    await clearConversationState(chatId);

    const keyboard: InlineKeyboard = [
      ...chunk(
        TIME_SLOTS.filter((t) => t.key !== "custom").map((t) => ({
          text: t.label,
          callback_data: `time:${request.id}:${t.key}`,
        })),
        2,
      ),
      [{ text: TIME_SLOTS.find((t) => t.key === "custom")!.label, callback_data: `time:${request.id}:custom` }],
    ];
    await sendMessage(chatId, "ممنون 🙏 حالا زمان مناسب برای مراجعه رو انتخاب کن:", keyboard);
    return;
  }

  if (state.state === "awaiting_custom_time") {
    await scheduleRequest(chatId, request.id, text);
    await clearConversationState(chatId);
    return;
  }
}

async function scheduleRequest(chatId: string, requestId: number, preferredTime: string): Promise<void> {
  await updateRequest(requestId, {
    preferredTime,
    status: "scheduled",
    scheduledAt: new Date(),
  });
  await logEvent(requestId, "scheduled", `زمان: ${preferredTime}`);

  const full = await getRequestWithCustomer(requestId);
  if (!full) return;

  await sendMessage(
    chatId,
    [
      "✅ جمع‌آوری با موفقیت هماهنگ شد!",
      "",
      `آدرس: ${full.request.address ?? "-"}`,
      `زمان: ${preferredTime}`,
      full.request.quotedPrice ? `قیمت تقریبی: ${toToman(full.request.quotedPrice)} تومان` : "",
      "",
      "همکار ما با کارت شناسایی نمکی سر ساعت مراجعه می‌کنه. مبلغ نهایی بعد از وزن‌کشی حضوری همون‌جا بهت اعلام و پرداخت می‌شه 🙌",
    ]
      .filter(Boolean)
      .join("\n"),
  );

  const admin = adminChatId();
  if (!admin) return;

  const caption = [
    `📦 سفارش #${full.request.id} برای جمع‌آوری آماده است`,
    `مشتری: ${customerDisplayName(full.customer)} (${full.customer.chatId})`,
    `نوع کالا: ${wasteTypeLabel(full.request.wasteType)}`,
    `آدرس: ${full.request.address ?? "-"}`,
    `زمان درخواستی: ${preferredTime}`,
    full.request.quotedPrice ? `قیمت تقریبی: ${toToman(full.request.quotedPrice)} تومان` : "",
    detailUrl(full.request.id),
  ]
    .filter(Boolean)
    .join("\n");

  const keyboard: InlineKeyboard = [
    [{ text: "📦 جمع‌آوری انجام شد، ثبت وزن و مبلغ نهایی", callback_data: `adm_done:${requestId}` }],
  ];
  await sendMessage(admin, caption, keyboard);
}

function detailUrl(id: number): string {
  const base = appBaseUrl();
  return base ? `مشاهده جزئیات: ${base}/admin/requests/${id}` : "";
}

function customerDisplayName(customer: { firstName: string | null; lastName: string | null; username: string | null }): string {
  const name = [customer.firstName, customer.lastName].filter(Boolean).join(" ").trim();
  if (name) return name;
  if (customer.username) return `@${customer.username}`;
  return "مشتری";
}

// ---------------------------------------------------------------------------
// پیام‌های ادمین
// ---------------------------------------------------------------------------
async function handleAdminMessage(chatId: string, text: string): Promise<void> {
  if (text === "/start" || text === "/help") {
    await sendMessage(
      chatId,
      [
        "🛠 پنل مدیریت نمکی (از طریق چت)",
        "",
        "وقتی مشتری‌ای عکس بفرسته و نوع کالا رو مشخص کنه، درخواستش با دکمه‌های عملیاتی برات ارسال می‌شه.",
        "دستورهای موجود:",
        "/stats — آمار کلی پایلوت",
      ].join("\n"),
    );
    return;
  }

  if (text === "/stats") {
    await sendAdminStats(chatId);
    return;
  }

  const state = await getConversationState(chatId);
  if (!state) {
    await sendMessage(chatId, "دستور نامشخص. برای راهنما /help رو بفرست.");
    return;
  }

  if (state.state === "awaiting_quote" && state.requestId) {
    const amount = parseIntLoose(text);
    if (amount === null || amount <= 0) {
      await sendMessage(chatId, "مبلغ نامعتبره. لطفاً فقط عدد بفرست (مثلاً 85000).");
      return;
    }
    await sendQuoteToCustomer(chatId, state.requestId, amount);
    await clearConversationState(chatId);
    return;
  }

  if (state.state === "awaiting_weight" && state.requestId) {
    const weight = parseFloatLoose(text);
    if (weight === null || weight <= 0) {
      await sendMessage(chatId, "وزن نامعتبره. لطفاً فقط عدد بفرست (مثلاً 4.5).");
      return;
    }
    await setConversationState(chatId, "awaiting_final_price", state.requestId, { weight });
    await sendMessage(chatId, `وزن ${weight} کیلوگرم ثبت شد.\nحالا مبلغ نهایی پرداختی به مشتری (تومان) رو بفرست:`);
    return;
  }

  if (state.state === "awaiting_final_price" && state.requestId) {
    const finalPrice = parseIntLoose(text);
    if (finalPrice === null || finalPrice <= 0) {
      await sendMessage(chatId, "مبلغ نامعتبره. لطفاً فقط عدد بفرست (مثلاً 92000).");
      return;
    }
    const weight = Number((state.data as { weight?: number } | null)?.weight ?? 0);
    await completeRequest(chatId, state.requestId, weight, finalPrice);
    await clearConversationState(chatId);
    return;
  }
}

async function sendAdminStats(chatId: string): Promise<void> {
  const all = await db.select().from(pickupRequests);
  const total = all.length;
  const completed = all.filter((r) => r.status === "completed");
  const lowValue = all.filter((r) => r.status === "low_value_queued").length;
  const cancelled = all.filter((r) => r.status === "cancelled" || r.status === "rejected").length;
  const sumFinal = completed.reduce((s, r) => s + (r.finalPrice ?? 0), 0);
  const sumReward = completed.reduce((s, r) => s + (r.rewardAmount ?? 0), 0);
  const completionRate = total > 0 ? Math.round((completed.length / total) * 100) : 0;

  const customerIds = new Set(all.map((r) => r.customerId));
  const countsByCustomer = new Map<number, number>();
  for (const r of all) countsByCustomer.set(r.customerId, (countsByCustomer.get(r.customerId) ?? 0) + 1);
  const repeatCustomers = [...countsByCustomer.values()].filter((c) => c >= 2).length;
  const repeatRate = customerIds.size > 0 ? Math.round((repeatCustomers / customerIds.size) * 100) : 0;

  await sendMessage(
    chatId,
    [
      "📊 آمار کلی پایلوت نمکی",
      "",
      `تعداد کل درخواست‌ها: ${total}`,
      `تعداد مشتریان یکتا: ${customerIds.size}`,
      `درخواست‌های تکمیل‌شده: ${completed.length}`,
      `درخواست‌های کم‌ارزش (نوبت تجمیعی): ${lowValue}`,
      `درخواست‌های لغو/رد شده: ${cancelled}`,
      `نرخ تکمیل: ${completionRate}٪`,
      `نرخ بازگشت مشتری: ${repeatRate}٪`,
      "",
      `مجموع مبلغ خرید نهایی: ${toToman(sumFinal)} تومان`,
      `مجموع پاداش/اعتبار پرداختی: ${toToman(sumReward)} تومان`,
    ].join("\n"),
  );
}

// ---------------------------------------------------------------------------
// Callback Query ها (دکمه‌های شیشه‌ای)
// ---------------------------------------------------------------------------
async function handleCallbackQuery(cq: BaleCallbackQuery): Promise<void> {
  await answerCallbackQuery(cq.id);
  if (!cq.data || !cq.message) return;

  const chatId = String(cq.message.chat.id);
  const messageId = cq.message.message_id;
  const [action, idStr, extra] = cq.data.split(":");
  const requestId = Number(idStr);
  if (Number.isNaN(requestId)) return;

  if (action === "wt") {
    await onWasteTypeSelected(chatId, messageId, requestId, extra);
    return;
  }
  if (action === "confirm") {
    await onCustomerConfirm(chatId, messageId, requestId);
    return;
  }
  if (action === "cancel") {
    await onCustomerCancel(chatId, messageId, requestId);
    return;
  }
  if (action === "time") {
    await onTimeSlotSelected(chatId, messageId, requestId, extra);
    return;
  }

  // اکشن‌های زیر فقط برای ادمین مجاز است
  if (!isAdmin(chatId)) return;

  if (action === "adm_q") {
    await onAdminStartQuote(chatId, messageId, requestId);
    return;
  }
  if (action === "adm_r") {
    await onAdminReject(chatId, messageId, requestId);
    return;
  }
  if (action === "adm_done") {
    await onAdminStartCompletion(chatId, messageId, requestId);
    return;
  }
}

async function onWasteTypeSelected(
  chatId: string,
  messageId: number,
  requestId: number,
  typeKey: string,
): Promise<void> {
  const request = await getRequestById(requestId);
  if (!request || request.status !== "awaiting_type") return;

  await updateRequest(requestId, { wasteType: typeKey, status: "awaiting_review" });
  await logEvent(requestId, "awaiting_review", `نوع انتخابی: ${wasteTypeLabel(typeKey)}`);
  await editMessageReplyMarkup(chatId, messageId, []);

  await sendMessage(
    chatId,
    `ثبت شد ✅ نوع: ${wasteTypeLabel(typeKey)}\nدرخواستت برای بررسی قیمت به تیم نمکی ارسال شد. معمولاً تا ۳۰ دقیقه بازه قیمت رو اعلام می‌کنیم ⏱`,
  );

  const admin = adminChatId();
  if (!admin) return;
  const customer = await getCustomerById(request.customerId);
  const caption = [
    `📸 درخواست جدید #${request.id}`,
    `مشتری: ${customer ? customerDisplayName(customer) : "?"} (${customer?.chatId ?? "-"})`,
    `نوع کالا: ${wasteTypeLabel(typeKey)}`,
    detailUrl(request.id),
    "",
    "برای اعلام قیمت روی دکمه زیر بزن:",
  ]
    .filter(Boolean)
    .join("\n");

  const keyboard: InlineKeyboard = [
    [{ text: "💰 ثبت قیمت پیشنهادی", callback_data: `adm_q:${requestId}` }],
    [{ text: "🚫 رد کردن (کم‌ارزش)", callback_data: `adm_r:${requestId}` }],
  ];

  if (request.photoFileId) {
    await sendPhotoByFileId(admin, request.photoFileId, caption, keyboard);
  } else {
    await sendMessage(admin, caption, keyboard);
  }
}

async function onAdminStartQuote(chatId: string, messageId: number, requestId: number): Promise<void> {
  const request = await getRequestById(requestId);
  if (!request) return;
  await editMessageReplyMarkup(chatId, messageId, []);
  await setConversationState(chatId, "awaiting_quote", requestId);
  await sendMessage(chatId, `مبلغ پیشنهادی برای درخواست #${requestId} رو به تومان بفرست (فقط عدد):`);
}

async function sendQuoteToCustomer(adminChat: string, requestId: number, amount: number): Promise<void> {
  const full = await getRequestWithCustomer(requestId);
  if (!full) return;

  await updateRequest(requestId, { status: "quoted", quotedPrice: amount, quotedAt: new Date() });
  await logEvent(requestId, "quoted", `قیمت پیشنهادی: ${amount}`);

  const keyboard: InlineKeyboard = [
    [
      { text: "✅ تایید می‌کنم", callback_data: `confirm:${requestId}` },
      { text: "❌ انصراف", callback_data: `cancel:${requestId}` },
    ],
  ];

  await sendMessage(
    full.customer.chatId,
    [
      `قیمت پیشنهادی نمکی برای کالای شما: ${toToman(amount)} تومان 💰`,
      "این مبلغ تقریبی است و بعد از وزن‌کشی حضوری ممکن است کمی تغییر کند.",
      "آیا این پیشنهاد رو تایید می‌کنی؟",
    ].join("\n"),
    keyboard,
  );

  await sendMessage(adminChat, `✅ قیمت ${toToman(amount)} تومان برای مشتری #${requestId} ارسال شد.`);
}

async function onAdminReject(chatId: string, messageId: number, requestId: number): Promise<void> {
  const full = await getRequestWithCustomer(requestId);
  if (!full) return;

  await updateRequest(requestId, { status: "low_value_queued" });
  await logEvent(requestId, "low_value_queued", "توسط ادمین رد شد (کم‌ارزش)");
  await editMessageReplyMarkup(chatId, messageId, []);
  await sendMessage(chatId, `درخواست #${requestId} به‌عنوان کم‌ارزش علامت زده شد و در نوبت جمع‌آوری تجمیعی قرار گرفت.`);

  await sendMessage(
    full.customer.chatId,
    "با بررسی اولیه، ارزش این کالا کمتر از حد جمع‌آوری فوری نمکیه 🙏\nنگران نباش، درخواستت در نوبت جمع‌آوری تجمیعی محله‌ات ثبت شد و به‌محض تکمیل سفارش‌های نزدیک، بهت خبر می‌دیم.",
  );
}

async function onCustomerConfirm(chatId: string, messageId: number, requestId: number): Promise<void> {
  const full = await getRequestWithCustomer(requestId);
  if (!full || full.customer.chatId !== chatId) return;
  if (full.request.status !== "quoted") {
    await sendMessage(chatId, "این درخواست قبلاً پردازش شده است.");
    return;
  }

  await updateRequest(requestId, { status: "confirmed", confirmedAt: new Date() });
  await logEvent(requestId, "confirmed", "مشتری قیمت را تایید کرد");
  await editMessageReplyMarkup(chatId, messageId, []);
  await setConversationState(chatId, "awaiting_address", requestId);

  await sendMessage(
    chatId,
    "عالی! ✅ لطفاً آدرس دقیق محل جمع‌آوری رو همین‌جا برام بنویس (خیابان، کوچه، پلاک، واحد).",
  );
}

async function onCustomerCancel(chatId: string, messageId: number, requestId: number): Promise<void> {
  const full = await getRequestWithCustomer(requestId);
  if (!full || full.customer.chatId !== chatId) return;

  await updateRequest(requestId, { status: "cancelled" });
  await logEvent(requestId, "cancelled", "مشتری لغو کرد");
  await editMessageReplyMarkup(chatId, messageId, []);
  await clearConversationState(chatId);

  await sendMessage(chatId, "باشه، این درخواست لغو شد. هر وقت خواستی می‌تونی دوباره عکس بفرستی 🙏");

  const admin = adminChatId();
  if (admin) {
    await sendMessage(admin, `ℹ️ مشتری درخواست #${requestId} رو لغو کرد.`);
  }
}

async function onTimeSlotSelected(
  chatId: string,
  messageId: number,
  requestId: number,
  slotKey: string,
): Promise<void> {
  const full = await getRequestWithCustomer(requestId);
  if (!full || full.customer.chatId !== chatId) return;
  if (full.request.status !== "awaiting_time") return;

  await editMessageReplyMarkup(chatId, messageId, []);

  if (slotKey === "custom") {
    await setConversationState(chatId, "awaiting_custom_time", requestId);
    await sendMessage(chatId, "باشه، زمان موردنظرت رو به‌صورت متن بنویس (مثلاً: سه‌شنبه ساعت ۵ عصر).");
    return;
  }

  await scheduleRequest(chatId, requestId, timeSlotLabel(slotKey));
}

async function onAdminStartCompletion(chatId: string, messageId: number, requestId: number): Promise<void> {
  const request = await getRequestById(requestId);
  if (!request) return;

  await updateRequest(requestId, { status: "collected" });
  await logEvent(requestId, "collected", "جمع‌آوری‌کننده مراجعه کرد");
  await editMessageReplyMarkup(chatId, messageId, []);
  await setConversationState(chatId, "awaiting_weight", requestId);
  await sendMessage(chatId, "وزن نهایی کالا (به کیلوگرم) رو بفرست (فقط عدد، مثلاً 4.5):");
}

async function completeRequest(
  adminChat: string,
  requestId: number,
  weight: number,
  finalPrice: number,
): Promise<void> {
  const full = await getRequestWithCustomer(requestId);
  if (!full) return;

  const rewardPercent = await getRewardPercent();
  const rewardAmount = Math.round((finalPrice * rewardPercent) / 100);

  let inviteCode = full.customer.inviteCode;
  if (!inviteCode) {
    inviteCode = generateInviteCode(full.customer.id);
    await db.update(customers).set({ inviteCode }).where(eq(customers.id, full.customer.id));
  }

  await updateRequest(requestId, {
    finalWeightKg: String(weight),
    finalPrice,
    rewardPercent,
    rewardAmount,
    status: "completed",
    completedAt: new Date(),
  });
  await logEvent(requestId, "completed", `وزن: ${weight}کیلوگرم، مبلغ نهایی: ${finalPrice}، پاداش: ${rewardAmount}`);

  await sendMessage(
    adminChat,
    `✅ سفارش #${requestId} تکمیل شد.\nوزن: ${weight} کیلوگرم\nمبلغ نهایی: ${toToman(finalPrice)} تومان\nپاداش (${rewardPercent}٪): ${toToman(rewardAmount)} تومان`,
  );

  await sendMessage(
    full.customer.chatId,
    [
      "🎉 معامله با موفقیت تکمیل شد!",
      "",
      `وزن نهایی: ${weight} کیلوگرم`,
      `مبلغ خرید: ${toToman(finalPrice)} تومان`,
      `پاداش نمکی (${rewardPercent}٪): ${toToman(rewardAmount)} تومان`,
      `جمع قابل دریافت: ${toToman(finalPrice + rewardAmount)} تومان`,
      "",
      `کد دعوت اختصاصی شما: ${inviteCode}`,
      "این کد رو با دوستانت به اشتراک بگذار؛ دفعه بعد که سفارش دادی، این کد رو برامون بفرست تا پاداش ویژه بگیری 🙌",
      "",
      "ممنون که به نمکی اعتماد کردی! هر وقت کالای جدیدی داشتی، کافیه دوباره عکسش رو بفرستی 📷",
    ].join("\n"),
  );
}
