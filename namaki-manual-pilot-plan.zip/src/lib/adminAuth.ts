export const ADMIN_COOKIE_NAME = "namaki_admin_session";
