import { mkdir, writeFile } from "fs/promises";
import path from "path";
import crypto from "crypto";
import { downloadFile } from "@/lib/bale";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads", "bale");

/**
 * عکس ارسالی مشتری را از سرور بله دانلود و به‌صورت محلی ذخیره می‌کند تا در
 * داشبورد مدیریت قابل‌مشاهده باشد. اگر دانلود شکست بخورد، خطا throw می‌شود
 * ولی چون فراخوانی‌کننده fileId اصلی را هم نگه می‌دارد، ارسال مجدد عکس به
 * ادمین (بدون نیاز به فایل محلی) هنوز ممکن است.
 */
export async function savePhotoLocally(fileId: string): Promise<string | null> {
  try {
    const buffer = await downloadFile(fileId);
    await mkdir(UPLOAD_DIR, { recursive: true });
    const filename = `${Date.now()}_${crypto.randomBytes(6).toString("hex")}.jpg`;
    await writeFile(path.join(UPLOAD_DIR, filename), buffer);
    return `/uploads/bale/${filename}`;
  } catch (err) {
    console.error("savePhotoLocally failed:", err);
    return null;
  }
}
