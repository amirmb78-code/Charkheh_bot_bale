import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq } from "drizzle-orm";
import type { BaleUser } from "@/lib/baleTypes";

export function generateInviteCode(customerId: number): string {
  return `NMK${1000 + customerId}`;
}

export async function getOrCreateCustomer(chatId: string, from?: BaleUser) {
  const existing = await db.select().from(customers).where(eq(customers.chatId, chatId));
  if (existing.length > 0) {
    return existing[0];
  }

  const [created] = await db
    .insert(customers)
    .values({
      chatId,
      firstName: from?.first_name,
      lastName: from?.last_name,
      username: from?.username,
    })
    .returning();

  const inviteCode = generateInviteCode(created.id);
  const [updated] = await db
    .update(customers)
    .set({ inviteCode })
    .where(eq(customers.id, created.id))
    .returning();

  return updated;
}

export async function getCustomerById(id: number) {
  const rows = await db.select().from(customers).where(eq(customers.id, id));
  return rows[0] ?? null;
}
