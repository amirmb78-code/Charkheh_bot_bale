// ---------------------------------------------------------------------------
// کلاینت سبک برای API ربات پیام‌رسان بله (سازگار با Telegram Bot API)
// مستندات: https://tapi.bale.ai/
// ---------------------------------------------------------------------------

export interface InlineKeyboardButton {
  text: string;
  callback_data?: string;
  url?: string;
}

export type InlineKeyboard = InlineKeyboardButton[][];

function getToken(): string {
  const token = process.env.BALE_BOT_TOKEN;
  if (!token) {
    throw new Error("BALE_BOT_TOKEN تنظیم نشده است");
  }
  return token;
}

function apiUrl(method: string): string {
  return `https://tapi.bale.ai/bot${getToken()}/${method}`;
}

function fileUrl(filePath: string): string {
  return `https://tapi.bale.ai/file/bot${getToken()}/${filePath}`;
}

async function callApi<T = unknown>(
  method: string,
  payload?: Record<string, unknown>,
): Promise<T> {
  const res = await fetch(apiUrl(method), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload ?? {}),
    // جلوگیری از گیرکردن درخواست به‌صورت نامحدود
    signal: AbortSignal.timeout(20_000),
  });

  const json = (await res.json().catch(() => null)) as {
    ok?: boolean;
    result?: T;
    description?: string;
  } | null;

  if (!res.ok || !json || json.ok === false) {
    const description = json?.description ?? `HTTP ${res.status}`;
    throw new Error(`خطای Bale API در ${method}: ${description}`);
  }

  return json.result as T;
}

export async function sendMessage(
  chatId: string | number,
  text: string,
  keyboard?: InlineKeyboard,
): Promise<void> {
  try {
    await callApi("sendMessage", {
      chat_id: chatId,
      text,
      ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
    });
  } catch (err) {
    console.error("sendMessage failed:", err);
  }
}

/** ارسال عکس با استفاده از file_id موجود (بدون آپلود مجدد) */
export async function sendPhotoByFileId(
  chatId: string | number,
  fileId: string,
  caption?: string,
  keyboard?: InlineKeyboard,
): Promise<void> {
  try {
    await callApi("sendPhoto", {
      chat_id: chatId,
      photo: fileId,
      ...(caption ? { caption } : {}),
      ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
    });
  } catch (err) {
    console.error("sendPhotoByFileId failed:", err);
  }
}

export async function answerCallbackQuery(
  callbackQueryId: string,
  text?: string,
): Promise<void> {
  try {
    await callApi("answerCallbackQuery", {
      callback_query_id: callbackQueryId,
      ...(text ? { text } : {}),
    });
  } catch (err) {
    console.error("answerCallbackQuery failed:", err);
  }
}

export async function editMessageReplyMarkup(
  chatId: string | number,
  messageId: number,
  keyboard?: InlineKeyboard,
): Promise<void> {
  try {
    await callApi("editMessageReplyMarkup", {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: { inline_keyboard: keyboard ?? [] },
    });
  } catch (err) {
    // ویرایش ممکن است شکست بخورد (مثلاً پیام قدیمی)؛ خطای بحرانی نیست
    console.warn("editMessageReplyMarkup failed:", err);
  }
}

interface BaleFile {
  file_id: string;
  file_path: string;
}

export async function getFilePath(fileId: string): Promise<string> {
  const result = await callApi<BaleFile>("getFile", { file_id: fileId });
  return result.file_path;
}

export async function downloadFile(fileId: string): Promise<Buffer> {
  const filePath = await getFilePath(fileId);
  const res = await fetch(fileUrl(filePath), {
    signal: AbortSignal.timeout(30_000),
  });
  if (!res.ok) {
    throw new Error(`دانلود فایل ناموفق بود: HTTP ${res.status}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

export async function setWebhook(url: string): Promise<void> {
  await callApi("setWebhook", { url });
}

export async function deleteWebhook(): Promise<void> {
  await callApi("deleteWebhook", {});
}

export async function getWebhookInfo(): Promise<unknown> {
  return callApi("getWebhookInfo", {});
}
