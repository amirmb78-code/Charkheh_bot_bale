import { processBaleUpdate } from "@/lib/baleConversation";
import type { BaleUpdate } from "@/lib/baleTypes";

export const dynamic = "force-dynamic";

function isAuthorized(req: Request): boolean {
  const secret = process.env.BALE_WEBHOOK_SECRET;
  if (!secret) return true; // اگر سکرت تنظیم نشده، بررسی رد می‌شود
  const url = new URL(req.url);
  return url.searchParams.get("secret") === secret;
}

export async function POST(req: Request) {
  if (!isAuthorized(req)) {
    return Response.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }

  if (!process.env.BALE_BOT_TOKEN) {
    console.error("BALE_BOT_TOKEN تنظیم نشده است — وب‌هوک نادیده گرفته شد.");
    return Response.json({ ok: true });
  }

  let update: BaleUpdate | null = null;
  try {
    update = (await req.json()) as BaleUpdate;
  } catch {
    return Response.json({ ok: false, error: "invalid json" }, { status: 400 });
  }

  // بلافاصله ۲۰۰ برمی‌گردانیم تا بله دوباره ارسال نکند؛ پردازش را async انجام می‌دهیم
  // اما چون Next.js روی سرورلس اجرا نمی‌شود اینجا، منتظر تکمیل هم می‌مانیم تا خطاها لاگ شوند.
  try {
    await processBaleUpdate(update);
  } catch (err) {
    console.error("خطا در پردازش وب‌هوک بله:", err);
  }

  return Response.json({ ok: true });
}

export async function GET() {
  return Response.json({ ok: true, service: "namaki-bale-webhook" });
}
