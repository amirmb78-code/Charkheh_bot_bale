import { setWebhook, getWebhookInfo, deleteWebhook } from "@/lib/bale";

export const dynamic = "force-dynamic";

function isAuthorized(req: Request): boolean {
  const password = process.env.ADMIN_DASHBOARD_PASSWORD;
  if (!password) return false; // بدون رمز تنظیم‌شده، این مسیر غیرفعال است
  const url = new URL(req.url);
  const provided = url.searchParams.get("password") ?? req.headers.get("x-admin-password");
  return provided === password;
}

export async function POST(req: Request) {
  if (!isAuthorized(req)) {
    return Response.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  if (!process.env.BALE_BOT_TOKEN) {
    return Response.json({ ok: false, error: "BALE_BOT_TOKEN تنظیم نشده است" }, { status: 400 });
  }
  const base = process.env.APP_BASE_URL;
  if (!base) {
    return Response.json({ ok: false, error: "APP_BASE_URL تنظیم نشده است" }, { status: 400 });
  }

  const secret = process.env.BALE_WEBHOOK_SECRET;
  const webhookUrl = `${base.replace(/\/$/, "")}/api/bale/webhook${secret ? `?secret=${encodeURIComponent(secret)}` : ""}`;

  try {
    await setWebhook(webhookUrl);
    return Response.json({ ok: true, webhookUrl });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  if (!isAuthorized(req)) {
    return Response.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  try {
    await deleteWebhook();
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

export async function GET(req: Request) {
  if (!isAuthorized(req)) {
    return Response.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  if (!process.env.BALE_BOT_TOKEN) {
    return Response.json({ ok: false, error: "BALE_BOT_TOKEN تنظیم نشده است" }, { status: 400 });
  }
  try {
    const info = await getWebhookInfo();
    return Response.json({ ok: true, info });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
