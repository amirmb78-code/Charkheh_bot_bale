import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "نمکی | پایلوت جمع‌آوری پسماند خشک و کالای دسته‌دوم",
  description:
    "نمکی — پایلوت دستی جمع‌آوری پسماند خشک و کالای دسته‌دوم در تهران، همراه با ربات بله و داشبورد مدیریت.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
