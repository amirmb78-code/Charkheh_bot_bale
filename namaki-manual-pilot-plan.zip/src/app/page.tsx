import Link from "next/link";

const steps = [
  {
    title: "۱. مشتری عکس می‌فرستد",
    text: "مشتری در چت بله، یک عکس واضح از پسماند خشک یا کالای دسته‌دوم را برای ربات نمکی ارسال می‌کند.",
  },
  {
    title: "۲. انتخاب نوع کالا",
    text: "ربات با دکمه‌های شیشه‌ای، نوع کالا (کاغذ، پلاستیک، فلز، شیشه، کالای دسته‌دوم) را از مشتری می‌پرسد.",
  },
  {
    title: "۳. بررسی و اعلام قیمت",
    text: "ادمین عکس را می‌بیند و بازه قیمت را در چت بله اعلام می‌کند؛ قیمت با دکمه‌های «تایید» و «انصراف» برای مشتری ارسال می‌شود.",
  },
  {
    title: "۴. هماهنگی آدرس و زمان",
    text: "پس از تایید مشتری، آدرس و زمان مناسب مراجعه (با دکمه‌های سریع یا متن دلخواه) دریافت و برای ادمین ارسال می‌شود.",
  },
  {
    title: "۵. جمع‌آوری و تسویه نهایی",
    text: "بعد از مراجعه حضوری، وزن و مبلغ نهایی ثبت می‌شود و پاداش/اعتبار به‌صورت خودکار محاسبه و به مشتری اعلام می‌شود.",
  },
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-emerald-50 to-slate-100">
      <div className="mx-auto max-w-4xl px-4 py-16">
        <div className="text-center">
          <div className="mb-4 text-5xl">🧂</div>
          <h1 className="text-3xl font-extrabold text-slate-900 sm:text-4xl">نمکی</h1>
          <p className="mx-auto mt-3 max-w-xl text-slate-600">
            پایلوت دستی جمع‌آوری پسماند خشک و کالای دسته‌دوم در تهران — با کمک ربات بله و یک داشبورد سبک مدیریت،
            بدون نیاز به توسعه اپلیکیشن.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <Link
              href="/admin"
              className="rounded-lg bg-emerald-600 px-5 py-2.5 font-medium text-white shadow hover:bg-emerald-700"
            >
              ورود به داشبورد مدیریت
            </Link>
          </div>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2">
          {steps.map((s) => (
            <div key={s.title} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
              <h2 className="font-bold text-slate-900">{s.title}</h2>
              <p className="mt-2 text-sm text-slate-600">{s.text}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="font-bold text-slate-900">راه‌اندازی ربات بله</h2>
          <ol className="mt-3 list-inside list-decimal space-y-2 text-sm text-slate-600">
            <li>
              متغیرهای محیطی <code className="rounded bg-slate-100 px-1">BALE_BOT_TOKEN</code>،{" "}
              <code className="rounded bg-slate-100 px-1">ADMIN_CHAT_ID</code>،{" "}
              <code className="rounded bg-slate-100 px-1">ADMIN_DASHBOARD_PASSWORD</code> و{" "}
              <code className="rounded bg-slate-100 px-1">APP_BASE_URL</code> را تنظیم کنید.
            </li>
            <li>وارد داشبورد مدیریت شوید تا وضعیت اتصال ربات را ببینید.</li>
            <li>
              با یک درخواست <code className="rounded bg-slate-100 px-1">POST</code> به مسیر{" "}
              <code className="rounded bg-slate-100 px-1">/api/bale/setup</code> وب‌هوک ربات را فعال کنید.
            </li>
            <li>از چت بله، دستور /start را برای ربات بفرستید و یک عکس آزمایشی ارسال کنید.</li>
          </ol>
        </div>

        <p className="mt-8 text-center text-xs text-slate-400">
          نسخه فنی پیش از پایلوت — بر اساس سند «نمکی، تهران، پلن اجرایی پایلوت دستی نسخه ۳»
        </p>
      </div>
    </main>
  );
}
