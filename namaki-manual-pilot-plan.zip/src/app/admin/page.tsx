import { db } from "@/db";
import { pickupRequests, customers } from "@/db/schema";
import { toToman } from "@/lib/persian";

export const dynamic = "force-dynamic";

async function loadStats() {
  const requests = await db.select().from(pickupRequests);
  const allCustomers = await db.select().from(customers);

  const total = requests.length;
  const completed = requests.filter((r) => r.status === "completed");
  const lowValue = requests.filter((r) => r.status === "low_value_queued").length;
  const cancelled = requests.filter((r) => r.status === "cancelled" || r.status === "rejected").length;
  const inProgress = total - completed.length - lowValue - cancelled;
  const sumFinal = completed.reduce((s, r) => s + (r.finalPrice ?? 0), 0);
  const sumReward = completed.reduce((s, r) => s + (r.rewardAmount ?? 0), 0);
  const completionRate = total > 0 ? Math.round((completed.length / total) * 100) : 0;

  const countsByCustomer = new Map<number, number>();
  for (const r of requests) countsByCustomer.set(r.customerId, (countsByCustomer.get(r.customerId) ?? 0) + 1);
  const repeatCustomers = [...countsByCustomer.values()].filter((c) => c >= 2).length;
  const repeatRate = allCustomers.length > 0 ? Math.round((repeatCustomers / allCustomers.length) * 100) : 0;

  return {
    total,
    customers: allCustomers.length,
    completed: completed.length,
    lowValue,
    cancelled,
    inProgress,
    sumFinal,
    sumReward,
    completionRate,
    repeatRate,
  };
}

function Card({ title, value, hint }: { title: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="text-sm text-slate-500">{title}</div>
      <div className="mt-1 text-2xl font-bold text-slate-900">{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-400">{hint}</div>}
    </div>
  );
}

export default async function AdminDashboardPage() {
  const stats = await loadStats();
  const base = process.env.APP_BASE_URL;
  const webhookConfigured = Boolean(process.env.BALE_BOT_TOKEN && process.env.ADMIN_CHAT_ID);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">داشبورد پایلوت نمکی</h1>
        <p className="mt-1 text-sm text-slate-500">
          شاخص‌های کلیدی پایلوت جمع‌آوری پسماند خشک و کالای دسته‌دوم در تهران
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Card title="کل درخواست‌ها" value={String(stats.total)} />
        <Card title="مشتریان یکتا" value={String(stats.customers)} />
        <Card title="تکمیل‌شده" value={String(stats.completed)} hint={`نرخ تکمیل: ${stats.completionRate}٪`} />
        <Card title="در جریان" value={String(stats.inProgress)} />
        <Card title="کم‌ارزش (نوبت تجمیعی)" value={String(stats.lowValue)} />
        <Card title="لغو/رد شده" value={String(stats.cancelled)} />
        <Card title="نرخ بازگشت مشتری" value={`${stats.repeatRate}٪`} hint="هدف پایلوت: حداقل ۱۵٪" />
        <Card title="مجموع خرید نهایی" value={`${toToman(stats.sumFinal)} تومان`} />
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="text-sm text-slate-500">مجموع پاداش/اعتبار پرداخت‌شده به مشتریان</div>
        <div className="mt-1 text-xl font-bold text-emerald-700">{toToman(stats.sumReward)} تومان</div>
      </div>

      <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
        <h2 className="font-bold text-amber-900">وضعیت اتصال ربات بله</h2>
        {webhookConfigured ? (
          <p className="mt-1 text-sm text-amber-800">
            متغیرهای محیطی BALE_BOT_TOKEN و ADMIN_CHAT_ID تنظیم شده‌اند ✅
          </p>
        ) : (
          <p className="mt-1 text-sm text-amber-800">
            برای فعال‌سازی ربات، متغیرهای محیطی BALE_BOT_TOKEN و ADMIN_CHAT_ID را در تنظیمات محیط تنظیم کنید.
          </p>
        )}
        <p className="mt-2 text-sm text-amber-800">
          پس از تنظیم توکن، برای متصل‌کردن وب‌هوک، متغیر APP_BASE_URL را برابر آدرس دامنه سایت قرار دهید (
          {base ?? "هنوز تنظیم نشده"}) و سپس درخواست زیر را اجرا کنید:
        </p>
        <pre className="mt-2 overflow-x-auto rounded-lg bg-slate-900 p-3 text-left text-xs text-emerald-300" dir="ltr">
          {`curl -X POST "${base ?? "https://YOUR_DOMAIN"}/api/bale/setup?password=YOUR_ADMIN_DASHBOARD_PASSWORD"`}
        </pre>
        <p className="mt-2 text-xs text-amber-700">
          برای قطع اتصال ربات می‌توانید همین درخواست را با متد DELETE ارسال کنید.
        </p>
      </div>
    </div>
  );
}
