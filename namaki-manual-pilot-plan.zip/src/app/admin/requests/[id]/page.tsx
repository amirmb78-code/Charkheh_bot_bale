import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { requestEvents, requestStatusEnum } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { getRequestWithCustomer } from "@/lib/requests";
import { statusLabel, wasteTypeLabel, toToman } from "@/lib/persian";
import { overrideStatusAction } from "@/app/admin/actions";

export const dynamic = "force-dynamic";

export default async function RequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const requestId = Number(id);
  if (Number.isNaN(requestId)) notFound();

  const full = await getRequestWithCustomer(requestId);
  if (!full) notFound();

  const events = await db
    .select()
    .from(requestEvents)
    .where(eq(requestEvents.requestId, requestId))
    .orderBy(asc(requestEvents.createdAt));

  const { request, customer } = full;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/admin/requests" className="text-sm text-emerald-700 hover:underline">
            ← بازگشت به لیست درخواست‌ها
          </Link>
          <h1 className="mt-1 text-2xl font-bold text-slate-900">درخواست #{request.id}</h1>
        </div>
        <span className="rounded-full bg-slate-100 px-3 py-1 text-sm">{statusLabel(request.status)}</span>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="space-y-4 md:col-span-2">
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <h2 className="mb-3 font-bold text-slate-900">اطلاعات درخواست</h2>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-slate-500">نوع کالا</dt>
                <dd className="font-medium">{wasteTypeLabel(request.wasteType)}</dd>
              </div>
              <div>
                <dt className="text-slate-500">قیمت پیشنهادی</dt>
                <dd className="font-medium">{request.quotedPrice ? `${toToman(request.quotedPrice)} تومان` : "-"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">آدرس</dt>
                <dd className="font-medium">{request.address ?? "-"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">زمان درخواستی</dt>
                <dd className="font-medium">{request.preferredTime ?? "-"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">وزن نهایی</dt>
                <dd className="font-medium">{request.finalWeightKg ? `${request.finalWeightKg} کیلوگرم` : "-"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">مبلغ نهایی</dt>
                <dd className="font-medium">{request.finalPrice ? `${toToman(request.finalPrice)} تومان` : "-"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">پاداش پرداختی</dt>
                <dd className="font-medium">
                  {request.rewardAmount ? `${toToman(request.rewardAmount)} تومان (${request.rewardPercent}٪)` : "-"}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">تاریخ ثبت</dt>
                <dd className="font-medium">{new Date(request.createdAt).toLocaleString("fa-IR")}</dd>
              </div>
            </dl>
          </div>

          {request.photoLocalPath && (
            <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
              <h2 className="mb-3 font-bold text-slate-900">عکس ارسالی مشتری</h2>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={request.photoLocalPath}
                alt={`عکس درخواست ${request.id}`}
                className="max-h-96 w-auto rounded-lg border border-slate-200"
              />
            </div>
          )}

          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <h2 className="mb-3 font-bold text-slate-900">تاریخچه وضعیت</h2>
            <ul className="space-y-2 text-sm">
              {events.map((e) => (
                <li key={e.id} className="flex items-start gap-2 border-r-2 border-emerald-200 pr-3">
                  <div>
                    <div className="font-medium text-slate-800">{statusLabel(e.status)}</div>
                    {e.note && <div className="text-slate-500">{e.note}</div>}
                    <div className="text-xs text-slate-400">{new Date(e.createdAt).toLocaleString("fa-IR")}</div>
                  </div>
                </li>
              ))}
              {events.length === 0 && <li className="text-slate-400">رویدادی ثبت نشده.</li>}
            </ul>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <h2 className="mb-3 font-bold text-slate-900">اطلاعات مشتری</h2>
            <dl className="space-y-2 text-sm">
              <div>
                <dt className="text-slate-500">نام</dt>
                <dd className="font-medium">
                  {[customer.firstName, customer.lastName].filter(Boolean).join(" ") || "-"}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">یوزرنیم بله</dt>
                <dd className="font-medium">{customer.username ? `@${customer.username}` : "-"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">چت‌آیدی</dt>
                <dd className="font-medium">{customer.chatId}</dd>
              </div>
              <div>
                <dt className="text-slate-500">کد دعوت</dt>
                <dd className="font-medium">{customer.inviteCode ?? "-"}</dd>
              </div>
            </dl>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <h2 className="mb-3 font-bold text-slate-900">تغییر دستی وضعیت</h2>
            <p className="mb-2 text-xs text-slate-500">
              معمولاً وضعیت از طریق گفتگوی ربات با مشتری/ادمین به‌روزرسانی می‌شود؛ این بخش فقط برای مواقع استثنایی است.
            </p>
            <form action={overrideStatusAction} className="flex flex-col gap-2">
              <input type="hidden" name="id" value={request.id} />
              <select
                name="status"
                defaultValue={request.status}
                className="rounded-lg border border-slate-300 px-2 py-1.5 text-sm"
              >
                {requestStatusEnum.enumValues.map((s) => (
                  <option key={s} value={s}>
                    {statusLabel(s)}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                className="rounded-lg bg-slate-800 px-3 py-1.5 text-sm text-white hover:bg-slate-900"
              >
                ذخیره
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
