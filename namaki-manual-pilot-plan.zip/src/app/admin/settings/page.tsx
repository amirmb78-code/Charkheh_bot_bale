import { getMaterialRates, getMinAcceptValue, getRewardPercent } from "@/lib/settings";
import { updateMaterialRateAction, updateGeneralSettingsAction } from "@/app/admin/actions";
import { wasteTypeLabel } from "@/lib/persian";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const rates = await getMaterialRates();
  const minAccept = await getMinAcceptValue();
  const rewardPercent = await getRewardPercent();

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">تنظیمات نرخ خرید و پاداش</h1>

      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="mb-3 font-bold text-slate-900">نرخ خرید هر نوع پسماند (تومان به ازای کیلوگرم)</h2>
        <div className="space-y-2">
          {rates.map((rate) => (
            <form
              key={rate.id}
              action={updateMaterialRateAction}
              className="flex items-center gap-3 rounded-lg border border-slate-100 p-2"
            >
              <input type="hidden" name="id" value={rate.id} />
              <span className="w-32 text-sm text-slate-700">{wasteTypeLabel(rate.material) || rate.label}</span>
              <input
                type="number"
                name="pricePerKg"
                defaultValue={rate.pricePerKg}
                min={0}
                className="w-32 rounded-lg border border-slate-300 px-2 py-1 text-sm"
              />
              <span className="text-xs text-slate-400">تومان/کیلوگرم</span>
              <button
                type="submit"
                className="mr-auto rounded-lg bg-emerald-600 px-3 py-1 text-sm text-white hover:bg-emerald-700"
              >
                ذخیره
              </button>
            </form>
          ))}
        </div>
        <p className="mt-2 text-xs text-slate-400">
          توجه: قیمت نهایی برای کالای دسته‌دوم به‌صورت موردی و توسط ادمین در همان لحظه اعلام می‌شود؛ این نرخ‌ها راهنمای
          پسماند خشک است.
        </p>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="mb-3 font-bold text-slate-900">تنظیمات کلی</h2>
        <form action={updateGeneralSettingsAction} className="space-y-3">
          <div>
            <label className="mb-1 block text-sm text-slate-700">حداقل ارزش پذیرش برای اعزام فوری (تومان)</label>
            <input
              type="number"
              name="minAcceptValue"
              defaultValue={minAccept}
              min={0}
              className="w-48 rounded-lg border border-slate-300 px-2 py-1.5 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm text-slate-700">درصد پاداش/اعتبار به مشتری</label>
            <input
              type="number"
              name="rewardPercent"
              defaultValue={rewardPercent}
              min={0}
              max={100}
              className="w-48 rounded-lg border border-slate-300 px-2 py-1.5 text-sm"
            />
          </div>
          <button
            type="submit"
            className="rounded-lg bg-emerald-600 px-4 py-1.5 text-sm text-white hover:bg-emerald-700"
          >
            ذخیره تنظیمات
          </button>
        </form>
      </div>
    </div>
  );
}
