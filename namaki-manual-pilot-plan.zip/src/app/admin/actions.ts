"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { materialRates, botSettings, pickupRequests, requestStatusEnum } from "@/db/schema";
import { logEvent } from "@/lib/requests";
import { ADMIN_COOKIE_NAME } from "@/lib/adminAuth";

export async function loginAction(formData: FormData): Promise<void> {
  const password = String(formData.get("password") ?? "");
  const expected = process.env.ADMIN_DASHBOARD_PASSWORD;

  if (!expected || password !== expected) {
    redirect("/admin/login?error=1");
  }

  const cookieStore = await cookies();
  cookieStore.set(ADMIN_COOKIE_NAME, expected, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });

  redirect("/admin");
}

export async function logoutAction(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(ADMIN_COOKIE_NAME);
  redirect("/admin/login");
}

export async function updateMaterialRateAction(formData: FormData): Promise<void> {
  const id = Number(formData.get("id"));
  const pricePerKg = Number(formData.get("pricePerKg"));
  if (!id || Number.isNaN(pricePerKg) || pricePerKg < 0) return;

  await db
    .update(materialRates)
    .set({ pricePerKg, updatedAt: new Date() })
    .where(eq(materialRates.id, id));

  revalidatePath("/admin/settings");
}

export async function updateGeneralSettingsAction(formData: FormData): Promise<void> {
  const minAccept = formData.get("minAcceptValue");
  const rewardPercent = formData.get("rewardPercent");

  if (minAccept !== null && String(minAccept).trim() !== "") {
    await db
      .insert(botSettings)
      .values({ key: "min_accept_value", value: String(minAccept) })
      .onConflictDoUpdate({
        target: botSettings.key,
        set: { value: String(minAccept), updatedAt: new Date() },
      });
  }

  if (rewardPercent !== null && String(rewardPercent).trim() !== "") {
    await db
      .insert(botSettings)
      .values({ key: "reward_percent", value: String(rewardPercent) })
      .onConflictDoUpdate({
        target: botSettings.key,
        set: { value: String(rewardPercent), updatedAt: new Date() },
      });
  }

  revalidatePath("/admin/settings");
}

export async function overrideStatusAction(formData: FormData): Promise<void> {
  const id = Number(formData.get("id"));
  const status = String(formData.get("status"));
  const validStatuses = requestStatusEnum.enumValues as readonly string[];
  if (!id || !validStatuses.includes(status)) return;

  await db
    .update(pickupRequests)
    .set({ status: status as (typeof requestStatusEnum.enumValues)[number], updatedAt: new Date() })
    .where(eq(pickupRequests.id, id));

  await logEvent(id, status, "تغییر دستی توسط ادمین از داشبورد");

  revalidatePath(`/admin/requests/${id}`);
  revalidatePath("/admin/requests");
}
